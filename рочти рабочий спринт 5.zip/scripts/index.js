// Проверка работы скрипта
console.log('JS - это боль (╬ ಠ益ಠ)');

// Создание массива
const initialCards = [
    {
        name: 'Архыз',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/arkhyz.jpg'
    },
    {
        name: 'Челябинская область',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/chelyabinsk-oblast.jpg'
    },
    {
        name: 'Иваново',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/ivanovo.jpg'
    },
    {
        name: 'Камчатка',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kamchatka.jpg'
    },
    {
        name: 'Холмогорский район',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/kholmogorsky-rayon.jpg'
    },
    {
        name: 'Байкал',
        link: 'https://pictures.s3.yandex.net/frontend-developer/cards-compressed/baikal.jpg'
    }
];

// Выборка элементов попапа профиля
const popupElement = document.querySelector('.popup');
const popupCloseButtonElement = popupElement.querySelector('.popup__button-close');
const formElement = popupElement.querySelector('.popup__content');
const nameInput = popupElement.querySelector('.popup__name');
const professionInput = popupElement.querySelector('.popup__profession');

// Выборка элементов блока профиля
const popupOpenButtonElement = document.querySelector('.profile__edit-button');
const popupAddButtonElement = document.querySelector('.profile__add-button');
const profileProfession = document.querySelector('.profile__subtitle');

const profileName = document.querySelector('.profile__title');
const popupPhotoElement = document.querySelector('#popup-photo-card');

const photoCardsContainer = document.querySelector('.elements__container');
const popupPhotoElementCloseButton = popupPhotoElement.querySelector('.popup__button-close');
const addTemplate = document.querySelector('#template__elements').content.querySelector('.elements__photo').cloneNode(true);
const formPhotoElement = popupPhotoElement.querySelector('#popup-photo-content');
const photoCardElement = document.querySelector('.elements__photo');
const trashBin = document.querySelector('.elements__delete');

const photoName = document.querySelector('#popup__photo-name');
const photoLink = document.querySelector('#popup__photo-link');
const openPopupPhotoZoom = document.querySelector('#popup-photo-card-zoom');
const popupPhotoZoomElement = openPopupPhotoZoom.querySelector('.popup__photo-item');
const popupPhotoZoomSubtitle = openPopupPhotoZoom.querySelector('.popup__photo-subtitle');
const popupPhotoZoomClose = openPopupPhotoZoom.querySelector('.popup__button-close');

// Открытие попапа редактирования профиля
function openPopup(popupItem) {
    popupItem.classList.add('popup__is-opened');
};

//Добавление данных в карточки попапа профиля
const addProfileInfo = function () {
    nameInput.value = profileName.textContent;
    professionInput.value = profileProfession.textContent;
};

popupOpenButtonElement.addEventListener('click', () => {
    openPopup(popupElement);
    addProfileInfo();
});

// Открытие попапа редактирования фото-карточки
const openPopupPhotoCard = function () {
    openPopup(popupPhotoElement);
};

popupAddButtonElement.addEventListener('click', openPopupPhotoCard);

// Закрытие попапа
function closePopup(popupItem) {
    popupItem.classList.remove('popup__is-opened');
};

popupCloseButtonElement.addEventListener('click', function () {
    closePopup(popupElement);
});

//Обработка отправки введенных в попап данных
function formSubmitHandler(evt) {
    evt.preventDefault();
    profileName.textContent = nameInput.value;
    profileProfession.textContent = professionInput.value;
    closePopup(popupElement);
};

popupElement.addEventListener('submit', formSubmitHandler);

//Функция создания фото-контейнера (ミ●﹏☉ミ)
function generateCard(placeName, link) {
    const addPhotoContainer = addTemplate.cloneNode(true);
    const addPhoto = addPhotoContainer.querySelector('.elements__photo-card');
    const addPhotoName = addPhotoContainer.querySelector('.elements__paragraph');
    const addLike = addPhotoContainer.querySelector('.elements__like');
    const photoZoom = addPhotoContainer.querySelector('.elements__photo-card')

    addPhoto.src = link;
    addPhoto.alt = placeName;
    addPhotoName.textContent = placeName;

    addLike.addEventListener('click', addLikeElement);
    photoZoom.addEventListener('click', zoomPhotoElement);
    // trashBin.addEventListener('click', deletePhotoCards);
    
    return addPhotoContainer;
};

//Добавление лайка
const addLikeElement = (evt) => {
    evt.target.classList.toggle('elements__like-active');
}

const zoomPhotoElement = (placeName, link) => {
    openPopup(openPopupPhotoZoom);
    popupPhotoZoomElement.src = link;
    popupPhotoZoomElement.alt = placeName;
    popupPhotoZoomSubtitle.textContent = placeName;
};

popupPhotoZoomClose.addEventListener('click', function () {
    closePopup(openPopupPhotoZoom);
});

// const deletePhotoCards = (evt) => {
//     evt.target.closest(".elements__photo").remove();
//   };

//Обработка карточки
function renderCard(place, link) {
    photoCardsContainer.prepend(generateCard(place, link));
}

initialCards.forEach(function (item) {
    renderCard(item.name, item.link);
});

//Обработка отправки введенных в попап данных
function formSubmitHandler(evt) {
    evt.preventDefault();
    profileName.textContent = nameInput.value;
    profileProfession.textContent = professionInput.value;
    closePopup(popupElement);
};

//Сохранение карточки
popupPhotoElement.addEventListener('submit', function (evt) {
    evt.preventDefault();
    renderCard(photoName.value, photoLink.value);
    formPhotoElement.reset();
    closePopup(popupPhotoElement);
});

popupPhotoElementCloseButton.addEventListener('click', function () {
    closePopup(popupPhotoElement);
});
